# Voice Control

## Dependencies

`sudo apt-get install -y python3-pip python3-venv portaudio19-dev flac`
