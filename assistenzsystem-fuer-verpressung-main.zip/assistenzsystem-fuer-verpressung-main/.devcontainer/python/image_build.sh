pushd ".devcontainer/python"
docker build --tag "gitlab.ruhr-uni-bochum.de/menschenzentrierte-robotik/assistenzsystem-fuer-verpressung/devcontainer/python:latest" .
popd
